export declare class LoginDto {
    usuario: string;
    senha: string;
}
