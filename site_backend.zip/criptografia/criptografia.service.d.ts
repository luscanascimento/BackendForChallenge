export declare class CriptografiaService {
    saltOrRounds: number;
    criptografar(texto: string): Promise<string>;
    comparar(senha: any, hash: any): Promise<boolean>;
}
