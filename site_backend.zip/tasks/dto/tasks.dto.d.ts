export declare class TasksDto {
    id: number;
    titulo: string;
    descricao: string;
    prioridade: string;
    status: string;
}
