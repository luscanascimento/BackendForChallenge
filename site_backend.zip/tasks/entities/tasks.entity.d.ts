export declare class Task {
    id: number;
    titulo: string;
    descricao: string;
    prioridade: string;
    status: string;
    dataDeCriacao: string;
}
