export declare class User {
    id: number;
    usuario: string;
    senha: string;
    dataDeCriacao: string;
}
