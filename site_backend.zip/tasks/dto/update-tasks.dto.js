"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateTaskDto = void 0;
const mapped_types_1 = require("@nestjs/mapped-types");
const tasks_dto_1 = require("./tasks.dto");
class UpdateTaskDto extends (0, mapped_types_1.PartialType)(tasks_dto_1.TasksDto) {
}
exports.UpdateTaskDto = UpdateTaskDto;
//# sourceMappingURL=update-tasks.dto.js.map