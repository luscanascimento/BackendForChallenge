"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AbstractService = void 0;
class AbstractService {
    constructor(repository) {
        this.repository = repository;
    }
    criar(criarDados) {
        return this.repository.save(criarDados);
    }
    encontrarTodos() {
        return this.repository.find();
    }
    encontrarUm(id) {
        return this.repository.findOne(id);
    }
    atualizar(id, atualizarDados) {
        this.repository.update(id, atualizarDados);
        return this.encontrarUm(id);
    }
    remover(id) {
        return this.repository.delete(id);
    }
}
exports.AbstractService = AbstractService;
//# sourceMappingURL=abstract.service.js.map