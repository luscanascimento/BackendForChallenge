"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TasksDto = void 0;
class TasksDto {
}
exports.TasksDto = TasksDto;
//# sourceMappingURL=tasks.dto.js.map