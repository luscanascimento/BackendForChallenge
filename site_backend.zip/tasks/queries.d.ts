export declare const contaPorColunaQuery: (col: string) => string;
