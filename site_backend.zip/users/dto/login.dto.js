"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginDto = void 0;
class LoginDto {
}
exports.LoginDto = LoginDto;
//# sourceMappingURL=login.dto.js.map