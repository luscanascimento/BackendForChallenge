import { CreateUserDto } from './dto/create-user.dto';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { CriptografiaService } from 'src/criptografia/criptografia.service';
import { LoginDto } from './dto/login.dto';
import { AbstractService } from '../abstract.service';
export declare class UsersService extends AbstractService<User> {
    protected repository: Repository<User>;
    private hash;
    saltOrRounds: number;
    password: string;
    constructor(repository: Repository<User>, hash: CriptografiaService);
    criarSenha(createUserDto: CreateUserDto): Promise<any>;
    pesquisarPorUsuarioESenha(data: LoginDto): Promise<User>;
}
