"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contaPorColunaQuery = void 0;
const contaPorColunaQuery = (col) => `SELECT count(*) as quantidade, ${col} FROM task GROUP BY ${col}`;
exports.contaPorColunaQuery = contaPorColunaQuery;
//# sourceMappingURL=queries.js.map