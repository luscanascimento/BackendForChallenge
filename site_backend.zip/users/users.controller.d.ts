import { UsersService } from './users.service';
import { CreateUserDto } from './dto/create-user.dto';
import { UpdateUserDto } from './dto/update-user.dto';
import { LoginDto } from './dto/login.dto';
export declare class UsersController {
    private readonly usersService;
    constructor(usersService: UsersService);
    criar(createUserDto: CreateUserDto): Promise<any>;
    login(loginDto: LoginDto): Promise<import("./entities/user.entity").User>;
    encontrarTodos(): Promise<import("./entities/user.entity").User[]>;
    encontrarUm(id: string): Promise<import("./entities/user.entity").User>;
    atualizar(id: string, updateUserDto: UpdateUserDto): Promise<import("./entities/user.entity").User>;
    remove(id: string): Promise<import("typeorm").DeleteResult>;
}
