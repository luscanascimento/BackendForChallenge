export declare const contaPorStatusQuery = "";
