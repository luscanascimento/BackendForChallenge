import { Repository } from 'typeorm';
import { Task } from './entities/tasks.entity';
import { AbstractService } from '../abstract.service';
export declare class TasksService extends AbstractService<Task> {
    protected repository: Repository<Task>;
    colunasPermitidas: string[];
    constructor(repository: Repository<Task>);
    contaPorColuna(col: string): Promise<any>;
}
