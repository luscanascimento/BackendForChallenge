import { TasksDto } from './dto/tasks.dto';
import { TasksService } from './tasks.service';
import { UpdateTaskDto } from './dto/update-tasks.dto';
export declare class TasksController {
    private readonly tasksService;
    constructor(tasksService: TasksService);
    criar(tasksDto: TasksDto): Promise<any>;
    encontrarTodos(): Promise<import("./entities/tasks.entity").Task[]>;
    contarPorColuna(col: string): Promise<any>;
    encontrarUm(id: string): Promise<import("./entities/tasks.entity").Task>;
    atualizar(id: string, updateTaskDto: UpdateTaskDto): Promise<import("./entities/tasks.entity").Task>;
    remove(id: string): Promise<import("typeorm").DeleteResult>;
}
