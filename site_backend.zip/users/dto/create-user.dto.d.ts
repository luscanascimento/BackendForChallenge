export declare class CreateUserDto {
    usuario: string;
    senha: string;
}
