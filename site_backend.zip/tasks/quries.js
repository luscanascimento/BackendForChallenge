"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.contaPorStatusQuery = void 0;
exports.contaPorStatusQuery = '';
//# sourceMappingURL=quries.js.map