import { Repository } from 'typeorm';
export declare abstract class AbstractService<T> {
    protected repository: Repository<T>;
    constructor(repository: Repository<T>);
    criar(criarDados: any): Promise<any>;
    encontrarTodos(): Promise<T[]>;
    encontrarUm(id: number): Promise<T>;
    atualizar(id: number, atualizarDados: any): Promise<T>;
    remover(id: number): Promise<import("typeorm").DeleteResult>;
}
