import { TasksDto } from './tasks.dto';
declare const UpdateTaskDto_base: import("@nestjs/mapped-types").MappedType<Partial<TasksDto>>;
export declare class UpdateTaskDto extends UpdateTaskDto_base {
}
export {};
